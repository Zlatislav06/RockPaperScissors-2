﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RockPaperScissors
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }
        int brc = 0,brp=0;

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        public int Computerchoice()
        {
            Random random = new Random();
            int a = random.Next(1, 4);
            switch (a)
            {
                case 1:
                    {
                        pictureBox1.Image = Image.FromFile("C:\\Users\\Zlati\\source\\repos\\RockPaperScissors\\RockPaperScissors\\Rock.png");
                        break;
                    }
                case 2:
                    {
                        pictureBox1.Image = Image.FromFile("C:\\Users\\Zlati\\source\\repos\\RockPaperScissors\\RockPaperScissors\\Paper.png");
                        break;
                    }
                case 3:
                    {
                        pictureBox1.Image = Image.FromFile("C:\\Users\\Zlati\\source\\repos\\RockPaperScissors\\RockPaperScissors\\Scissors.png");
                        break;
                    }

            }
            return a;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            int a= Computerchoice();
            pictureBox2.Image = Image.FromFile("C:\\Users\\Zlati\\source\\repos\\RockPaperScissors\\RockPaperScissors\\Rock.png");
            if(a==1)
            {
                label3.ForeColor = Color.Black;
                label3.Text = "Result:Game is draw.";
                brc++;brp++;
            }
            else if(a==2)
            {
                label3.ForeColor= Color.Red;
                label3.Text = "Result:Player loses!";
                brc++;
            }
            else if(a==3)
            {
                label3.ForeColor = Color.Green;
                label3.Text = "Result:Player wins!";
                brp++;
            }   
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int a = Computerchoice();
            pictureBox2.Image = Image.FromFile("C:\\Users\\Zlati\\source\\repos\\RockPaperScissors\\RockPaperScissors\\Paper.png");
            if (a == 1)
            {
                label3.ForeColor = Color.Green;
                label3.Text = "Result:Player wins!";
                brp++;
            }
            else if (a == 2)
            {
                
                label3.ForeColor = Color.Black;
                label3.Text = "Result:Game is draw.";
                brc++;brp++;
            }
            else if (a == 3)
            {
                label3.ForeColor = Color.Red;
                label3.Text = "Result:Player loses!";
                brc++;
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int a = Computerchoice();
            pictureBox2.Image = Image.FromFile("C:\\Users\\Zlati\\source\\repos\\RockPaperScissors\\RockPaperScissors\\Scissors.png");
            if (a == 1)
            {
                
                label3.ForeColor = Color.Red;
                label3.Text = "Result:Player loses!";
                brc++;
            }
            else if (a == 2)
            {
                label3.ForeColor = Color.Green;
                label3.Text = "Result:Player wins!";
               brp++;
            }
            else if (a == 3)
            {
                label3.ForeColor = Color.Black;
                label3.Text = "Result:Game is draw.";
                brc++; brp++;
            }

        }
    

        private void label3_Click(object sender, EventArgs e)
        {
            if(brc==brp)
            {
                 MessageBox.Show($"Result:{brc} - {brp}.");
            }
            else if(brc>brp)
            {
                MessageBox.Show($"Result:{brc} - {brp}.\nComputer win!\nTry again!");
            }
            else 
            {
                MessageBox.Show($"Result:{brc} - {brp}.\nCongratulation!\nYou win!");

            }
            brc = 0;brp= 0;
        }
    }
}
